defmodule ProcessExampleTest do
  use ExUnit.Case
  doctest ProcessExample

  test "the truth" do
    assert 1 + 1 == 2
  end
end
