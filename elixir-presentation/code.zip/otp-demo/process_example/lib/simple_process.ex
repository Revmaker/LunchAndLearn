defmodule SimpleProcess do
  def greet do
    IO.puts "Hello"
  end
end
