defmodule SequenceServer do
  use GenServer

  def handle_call(:next_number, _from, current_number) do
    # Reply with the current state and the new state
    {:reply, current_number + 1, current_number + 1}
  end
end
