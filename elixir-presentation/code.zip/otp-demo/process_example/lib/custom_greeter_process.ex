defmodule CustomGreeterProcess do
  def greet do
    receive do
      {sender, person} -> send sender, {:ok, "Hello #{person}"}
    end
  end
end
