# ProcessExample

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed as:

  1. Add `process_example` to your list of dependencies in `mix.exs`:

    ```elixir
    def deps do
      [{:process_example, "~> 0.1.0"}]
    end
    ```

  2. Ensure `process_example` is started before your application:

    ```elixir
    def application do
      [applications: [:process_example]]
    end
    ```

