defmodule SequenceTest do
  use ExUnit.Case
  doctest Sequence

  test "the truth" do
    assert 1 + 1 == 2
  end
end
