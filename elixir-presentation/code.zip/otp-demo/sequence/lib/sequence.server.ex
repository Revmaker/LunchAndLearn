defmodule Sequence.Server do
  use GenServer
  # @vsn 0
  @vsn 1

  def next_number do
    GenServer.call( __MODULE__, :next_number)
  end

  def get_number do
    GenServer.call( __MODULE__, :get_number)
  end

  def increment_number(delta) do
    GenServer.cast __MODULE__, {:increment_number, delta}
  end

  def start_link(state) do
    GenServer.start_link(__MODULE__, state, name: __MODULE__)
  end

  def handle_call(:next_number, _from, current_number) do
    # Reply with the current state and the new state
    new_num = current_number + 1
    {:reply, new_num, new_num}
  end

  def handle_call(:get_number, _from, current_number) do
    # Reply with the current state and the new state
    {:reply, current_number, current_number}
  end

  # def handle_cast({:increment_number, delta}, current_number) do
  #   {:noreply, current_number + delta}
  # end

  def code_change("0", old_state, _extra) do
    IO.puts "Upgrading from v0 to v1"
    {:ok, old_state}
  end

  # Updated code here
  def handle_cast({:increment_number, delta}, current_number) do
    {:noreply, current_number + delta + 1}
  end

end
